import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContentSchema, insertWatchlistSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all content
  app.get("/api/content", async (req, res) => {
    try {
      const content = await storage.getAllContent();
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  // Get content by ID
  app.get("/api/content/:id", async (req, res) => {
    try {
      const content = await storage.getContentById(req.params.id);
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  // Get content by category
  app.get("/api/content/category/:category", async (req, res) => {
    try {
      const content = await storage.getContentByCategory(req.params.category);
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content by category" });
    }
  });

  // Get content by type
  app.get("/api/content/type/:type", async (req, res) => {
    try {
      const content = await storage.getContentByType(req.params.type);
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content by type" });
    }
  });

  // Search content
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const content = await storage.searchContent(query);
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to search content" });
    }
  });

  // Get user watchlist
  app.get("/api/watchlist/:userId", async (req, res) => {
    try {
      const watchlist = await storage.getWatchlistByUserId(req.params.userId);
      res.json(watchlist);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch watchlist" });
    }
  });

  // Add to watchlist
  app.post("/api/watchlist", async (req, res) => {
    try {
      const validatedData = insertWatchlistSchema.parse(req.body);
      const watchlistItem = await storage.addToWatchlist(validatedData);
      res.status(201).json(watchlistItem);
    } catch (error) {
      res.status(400).json({ message: "Invalid watchlist data" });
    }
  });

  // Remove from watchlist
  app.delete("/api/watchlist/:userId/:contentId", async (req, res) => {
    try {
      const { userId, contentId } = req.params;
      const removed = await storage.removeFromWatchlist(userId, contentId);
      if (removed) {
        res.status(200).json({ message: "Removed from watchlist" });
      } else {
        res.status(404).json({ message: "Watchlist item not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to remove from watchlist" });
    }
  });



  const httpServer = createServer(app);
  return httpServer;
}
