import { type Content, type InsertContent, type Watchlist, type InsertWatchlist } from "@shared/schema";
import { randomUUID } from "crypto";
import { contentDatabase } from "./content-data";

export interface IStorage {
  // Content methods
  getAllContent(): Promise<Content[]>;
  getContentById(id: string): Promise<Content | undefined>;
  getContentByCategory(category: string): Promise<Content[]>;
  getContentByType(type: string): Promise<Content[]>;
  searchContent(query: string): Promise<Content[]>;
  
  // Watchlist methods
  getWatchlistByUserId(userId: string): Promise<Watchlist[]>;
  addToWatchlist(watchlist: InsertWatchlist): Promise<Watchlist>;
  removeFromWatchlist(userId: string, contentId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private content: Map<string, Content>;
  private watchlist: Map<string, Watchlist>;

  constructor() {
    this.content = new Map();
    this.watchlist = new Map();
    this.seedData();
  }

  private seedData() {
    // Load content from the easy-to-edit data file
    contentDatabase.forEach(content => {
      this.content.set(content.id, content);
    });
  }

  async getAllContent(): Promise<Content[]> {
    return Array.from(this.content.values());
  }

  async getContentById(id: string): Promise<Content | undefined> {
    return this.content.get(id);
  }

  async getContentByCategory(category: string): Promise<Content[]> {
    return Array.from(this.content.values()).filter(
      content => content.category === category
    );
  }

  async getContentByType(type: string): Promise<Content[]> {
    return Array.from(this.content.values()).filter(
      content => content.type === type
    );
  }

  async searchContent(query: string): Promise<Content[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.content.values()).filter(
      content =>
        content.title.toLowerCase().includes(lowerQuery) ||
        content.description.toLowerCase().includes(lowerQuery) ||
        content.genre.toLowerCase().includes(lowerQuery)
    );
  }

  async getWatchlistByUserId(userId: string): Promise<Watchlist[]> {
    return Array.from(this.watchlist.values()).filter(
      item => item.userId === userId
    );
  }

  async addToWatchlist(insertWatchlist: InsertWatchlist): Promise<Watchlist> {
    const id = randomUUID();
    const watchlistItem: Watchlist = { ...insertWatchlist, id };
    this.watchlist.set(id, watchlistItem);
    return watchlistItem;
  }

  async removeFromWatchlist(userId: string, contentId: string): Promise<boolean> {
    const item = Array.from(this.watchlist.values()).find(
      w => w.userId === userId && w.contentId === contentId
    );
    if (item) {
      this.watchlist.delete(item.id);
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
