// StreamX Content Database
// Easy to edit - just add, modify, or remove content here

import { type Content } from "@shared/schema";

export const contentDatabase: Content[] = [
  {
    id: "1",
    title: "Sonic The Hedgehog 3",
    description: "The blue blur returns in his most thrilling adventure yet! Join Sonic, Tails, and Knuckles as they face their greatest challenge in this action-packed third installment of the beloved video game movie franchise.",
    year: 2024,
    duration: "1h 49m",
    genre: "Action",
    type: "movie",
    category: "trending",
    rating: "HD",
    thumbnailUrl: "https://m.media-amazon.com/images/I/916jcd+BQaL._UF894,1000_QL80_.jpg",
    googleDriveUrl: "https://drive.google.com/file/d/1fhs1fdOWIKyHxC63m_n2VOSWI2-jYg01/preview",
    isOriginal: 0
  },
  {
    id: "2",
    title: "A Minecraft Movie",
    description: "The beloved block-building game comes to life in this epic adventure! Join Steve and his friends as they explore the Overworld, battle mobs, and discover the true power of creativity and friendship in the pixelated world of Minecraft.",
    year: 2025,
    duration: "1h 40m",
    genre: "Adventure",
    type: "movie",
    category: "trending",
    rating: "HD",
    thumbnailUrl: "https://media-cache.cinematerial.com/p/500x/w1vk5k8s/a-minecraft-movie-movie-poster.jpg?v=1743750953",
    googleDriveUrl: "https://drive.google.com/file/d/1Oppg2lJlwwqKmPK8z4HNcdeiEyf6GaHq/preview",
    isOriginal: 0
  },
  {
    id: "3",
    title: "The Super Mario Bros. Movie",
    description: "Join Mario and Luigi on their incredible adventure through the Mushroom Kingdom! When the brothers are transported from Brooklyn to a magical new world, they must team up with Princess Peach to save the kingdom from the evil Bowser.",
    year: 2023,
    duration: "1h 32m",
    genre: "Animation",
    type: "movie",
    category: "original",
    rating: "HD",
    thumbnailUrl: "https://m.media-amazon.com/images/I/81VxuVBN1cL._UF894,1000_QL80_.jpg",
    googleDriveUrl: "https://drive.google.com/file/d/1OsyF2LKJqjtv0b2Xd9GWOLcYkzny3VZo/preview",
    isOriginal: 1
  },
  {
    id: "4",
    title: "Space Jam: A New Legacy",
    description: "LeBron James teams up with Bugs Bunny and the rest of the Looney Tunes for an epic basketball game against a rogue AI's digitized champions in the Warner 3000 Server-Verse to save his kidnapped son.",
    year: 2021,
    duration: "1h 55m",
    genre: "Family",
    type: "movie",
    category: "trending",
    rating: "HD",
    thumbnailUrl: "https://m.media-amazon.com/images/I/81BlauclfRL._UF1000,1000_QL80_.jpg",
    googleDriveUrl: "https://drive.google.com/file/d/1v2xqKQcAvndfcqsctZH73NR2AjFXsrUr/preview",
    isOriginal: 0
  },
  {
    id: "5",
    title: "Summer Hearts",
    description: "Romantic comedy about two rival food truck owners who discover love during a cross-country festival tour.",
    year: 2023,
    duration: "1h 58m",
    genre: "Romance",
    type: "movie",
    category: "popular",
    rating: "HD",
    thumbnailUrl: "https://images.unsplash.com/photo-1414609245224-afa02bfb3fda?w=800&h=450&fit=crop",
    googleDriveUrl: "https://drive.google.com/file/d/1SU3ugkkoUHEHjbzXVGjjIvd7Tz7YZfsO/preview",
    isOriginal: 0
  },
  {
    id: "6",
    title: "Ocean's Mystery",
    description: "Deep-sea adventure documentary revealing the secrets of the world's most unexplored ocean trenches.",
    year: 2024,
    duration: "1h 42m",
    genre: "Documentary",
    type: "movie",
    category: "popular",
    rating: "4K",
    thumbnailUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&h=450&fit=crop",
    googleDriveUrl: "https://drive.google.com/file/d/1SU3ugkkoUHEHjbzXVGjjIvd7Tz7YZfsO/preview",
    isOriginal: 1
  }
];

// How to add new content:
// 1. Copy one of the existing entries above
// 2. Change the id to a unique number/string
// 3. Update all the fields (title, description, year, etc.)
// 4. For Google Drive videos: "https://drive.google.com/file/d/YOUR_FILE_ID/preview"
// 5. Categories: "trending", "popular", "original"
// 6. Types: "movie", "tv"
// 7. Duration: For movies use "2h 15m" format, for TV use "8 Episodes"
// 8. Rating: "HD", "4K" (for video quality)
// 9. For thumbnails, use high-quality images (preferably 800x450 or similar aspect ratio)

// Example of adding a new movie:
/*
{
  id: "7",
  title: "Your Movie Title",
  description: "Your movie description here...",
  year: 2024,
  duration: "2h 10m", // For movies: "2h 15m", for TV: "10 Episodes"
  genre: "Action", // Action, Drama, Comedy, Thriller, Sci-Fi, etc.
  type: "movie", // "movie" or "tv"
  category: "trending", // "trending", "popular", or "original"
  rating: "HD", // "HD" or "4K" for video quality
  thumbnailUrl: "https://your-image-url.com/image.jpg",
  googleDriveUrl: "https://drive.google.com/file/d/YOUR_FILE_ID/preview",
  isOriginal: 0 // 1 for StreamX Originals, 0 for regular content
},
*/