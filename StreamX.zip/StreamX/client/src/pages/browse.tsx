import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navbar from "@/components/navbar";
import ContentCard from "@/components/content-card";
import { Content } from "@shared/schema";

export default function Browse() {
  const [, params] = useRoute("/browse/:category?");
  const [location, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState(params?.category || "all");
  const [searchQuery, setSearchQuery] = useState("");

  // Parse search query from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split("?")[1] || "");
    const query = urlParams.get("q");
    if (query) {
      setSearchQuery(query);
    }
  }, [location]);

  const { data: allContent, isLoading } = useQuery<Content[]>({
    queryKey: ["/api/content"],
  });

  const { data: searchResults } = useQuery<Content[]>({
    queryKey: ["/api/search"],
    queryFn: async () => {
      if (!searchQuery) return [];
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: !!searchQuery,
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setLocation(`/browse?q=${encodeURIComponent(query)}`);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setSearchQuery("");
    setLocation(`/browse${value !== "all" ? `/${value}` : ""}`);
  };

  const getFilteredContent = (type?: string) => {
    if (searchQuery && searchResults) {
      return searchResults;
    }

    if (!allContent) return [];

    switch (type) {
      case "movies":
        return allContent.filter(item => item.type === "movie");
      case "tv":
        return allContent.filter(item => item.type === "tv");
      case "original":
        return allContent.filter(item => item.isOriginal === 1);
      case "trending":
        return allContent.filter(item => item.category === "trending");
      case "popular":
        return allContent.filter(item => item.category === "popular");
      default:
        return allContent;
    }
  };

  const content = getFilteredContent(activeTab === "all" ? undefined : activeTab);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-stream-dark text-white">
        <Navbar onSearch={handleSearch} />
        <div className="pt-16 flex items-center justify-center h-screen">
          <div className="text-center animate-fade-in">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-primary rounded-lg p-4 animate-pulse-glow animate-float">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-primary-foreground">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
            </div>
            <div className="loading-shimmer w-32 h-4 rounded mx-auto mb-2"></div>
            <p className="text-gray-400 animate-pulse">Loading content...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stream-dark text-white">
      <Navbar onSearch={handleSearch} />
      
      <div className="pt-16 animate-fade-in">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8 animate-slide-up">
            <h1 className="text-4xl font-bold mb-2">
              {searchQuery ? `Search Results for "${searchQuery}"` : "Browse Content"}
            </h1>
            <p className="text-gray-400 animate-fade-in" style={{"animationDelay": "0.2s"} as any}>
              {content?.length || 0} {(content?.length || 0) === 1 ? "title" : "titles"} available
            </p>
          </div>

          {/* Tabs */}
          {!searchQuery && (
            <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-8 animate-slide-in">
              <TabsList className="grid w-full grid-cols-6 lg:w-auto bg-stream-gray">
                <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 hover:scale-105">
                  All
                </TabsTrigger>
                <TabsTrigger value="movies" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 hover:scale-105">
                  Movies
                </TabsTrigger>
                <TabsTrigger value="tv" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 hover:scale-105">
                  TV Shows
                </TabsTrigger>
                <TabsTrigger value="original" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 hover:scale-105">
                  Originals
                </TabsTrigger>
                <TabsTrigger value="trending" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 hover:scale-105">
                  Trending
                </TabsTrigger>
                <TabsTrigger value="popular" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all duration-300 hover:scale-105">
                  Popular
                </TabsTrigger>
              </TabsList>
            </Tabs>
          )}

          {/* Content Grid */}
          {content && content.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {content.map((item, index) => (
                <div 
                  key={item.id}
                  className="animate-fade-in stagger-animation"
                  style={{"--stagger": index} as any}
                >
                  <ContentCard
                    id={item.id}
                    title={item.title}
                    thumbnailUrl={item.thumbnailUrl}
                    genre={item.genre}
                    year={item.year}
                    duration={item.duration}
                    isOriginal={item.isOriginal === 1}
                    onClick={() => setLocation(`/watch/${item.id}`)}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 animate-fade-in">
              <div className="text-6xl mb-4 animate-float">🔍</div>
              <h3 className="text-2xl font-semibold mb-2 animate-slide-up">
                {searchQuery ? "No search results found" : "No content available"}
              </h3>
              <p className="text-gray-400 mb-6 animate-fade-in" style={{"animationDelay": "0.3s"} as any}>
                {searchQuery 
                  ? `Try adjusting your search terms or browse our categories.`
                  : "Check back later for new content."
                }
              </p>
              {searchQuery && (
                <Button 
                  onClick={() => {
                    setSearchQuery("");
                    setLocation("/browse");
                  }}
                  className="bg-primary text-primary-foreground transition-all duration-300 hover:scale-105 animate-pulse-glow animate-fade-in"
                  style={{"animationDelay": "0.5s"} as any}
                >
                  Clear Search
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
