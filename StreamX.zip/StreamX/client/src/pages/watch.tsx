import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, ThumbsUp } from "lucide-react";
import Navbar from "@/components/navbar";
import VideoPlayer from "@/components/video-player";
import ContentCard from "@/components/content-card";
import { Content } from "@shared/schema";

export default function Watch() {
  const [, params] = useRoute("/watch/:id");
  const contentId = params?.id;

  const { data: content, isLoading, error } = useQuery<Content>({
    queryKey: ["/api/content", contentId],
    enabled: !!contentId,
  });

  const { data: recommendations } = useQuery<Content[]>({
    queryKey: ["/api/content"],
    select: (data) => data?.filter(item => item.id !== contentId).slice(0, 4),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-stream-dark text-white">
        <Navbar />
        <div className="pt-16 flex items-center justify-center h-screen">
          <div className="text-primary text-2xl">Loading content...</div>
        </div>
      </div>
    );
  }

  if (error || !content) {
    return (
      <div className="min-h-screen bg-stream-dark text-white">
        <Navbar />
        <div className="pt-16 flex items-center justify-center h-screen">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Content Not Found</h1>
            <p className="text-gray-400 mb-6">The requested content could not be found.</p>
            <Link href="/">
              <Button className="bg-primary text-primary-foreground">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stream-dark text-white">
      <Navbar />

      <section className="pt-16 pb-16 bg-stream-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Video Player Column */}
            <div className="lg:col-span-2">
              <VideoPlayer
                googleDriveUrl={content.googleDriveUrl}
                title={content.title}
                onPlay={() => console.log('Playing:', content.title)}
                onPause={() => console.log('Paused:', content.title)}
              />

              {/* Video Info */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold mb-2">{content.title}</h1>
                    <div className="flex items-center space-x-4 text-gray-400 mb-4">
                      <span>{content.year}</span>
                      <span>•</span>
                      <span>{content.duration}</span>
                      <span>•</span>
                      {content.rating && (
                        <Badge className="bg-primary text-primary-foreground">
                          {content.rating}
                        </Badge>
                      )}
                      
                    </div>
                  </div>

                  <Link href="/">
                    <Button variant="ghost" size="icon">
                      <ArrowLeft className="w-5 h-5" />
                    </Button>
                  </Link>
                </div>

                <p className="text-gray-300 mb-6 text-lg leading-relaxed">
                  {content.description}
                </p>

                {/* Action Buttons */}
                <div className="flex items-center space-x-4">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                    <Plus className="w-4 h-4 mr-2" />
                    My List
                  </Button>
                  <Button variant="secondary" className="bg-gray-700 hover:bg-gray-600">
                    <ThumbsUp className="w-4 h-4 mr-2" />
                    Like
                  </Button>
                </div>
              </div>
            </div>

            {/* Recommendations Sidebar */}
            <div className="space-y-4">
              <h4 className="text-xl font-semibold mb-4">Up Next</h4>

              {recommendations?.map((item) => (
                <Link key={item.id} href={`/watch/${item.id}`}>
                  <div className="flex space-x-3 p-3 bg-stream-dark rounded-lg hover:bg-gray-800 transition-colors cursor-pointer">
                    <img 
                      src={item.thumbnailUrl}
                      alt={`${item.title} thumbnail`}
                      className="w-20 h-14 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h5 className="font-semibold text-sm truncate">{item.title}</h5>
                      <p className="text-gray-400 text-xs">
                        {item.duration} • {item.genre}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}