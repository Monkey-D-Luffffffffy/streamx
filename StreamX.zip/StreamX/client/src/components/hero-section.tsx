import { Button } from "@/components/ui/button";
import { Play, Info } from "lucide-react";
import { Link } from "wouter";

interface HeroSectionProps {
  featuredContent?: {
    id: string;
    title: string;
    description: string;
    thumbnailUrl: string;
  };
}

export default function HeroSection({ featuredContent }: HeroSectionProps) {
  const defaultContent = {
    id: "1",
    title: "The Next Generation of Streaming",
    description: "Experience unlimited entertainment with StreamX. Powered by your Google Drive content library.",
    thumbnailUrl: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=800"
  };

  const content = featuredContent || defaultContent;

  return (
    <section className="relative pt-16 h-screen overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 hero-gradient">
        <img 
          src={content.thumbnailUrl}
          alt={`${content.title} hero background`}
          className="w-full h-full object-cover opacity-40 transition-transform duration-[20s] ease-out hover:scale-110"
        />
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-full">
        <div className="max-w-2xl animate-slide-up">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 leading-tight animate-fade-in">
            {featuredContent ? (
              <span className="inline-block animate-slide-in" style={{"--stagger": 0} as any}>
                {content.title}
              </span>
            ) : (
              <>
                <span className="inline-block animate-slide-in" style={{"--stagger": 0} as any}>The Next</span>{" "}
                <span className="text-primary inline-block animate-slide-in animate-pulse-glow" style={{"--stagger": 1} as any}>Generation</span>{" "}
                <span className="inline-block animate-slide-in" style={{"--stagger": 2} as any}>of Streaming</span>
              </>
            )}
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed animate-fade-in" style={{"animationDelay": "0.3s"} as any}>
            {content.description}
          </p>
          <div className="flex space-x-4 animate-fade-in" style={{"animationDelay": "0.6s"} as any}>
            <Link href={`/watch/${content.id}`}>
              <Button className="bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-all duration-300 hover:scale-105 hover:shadow-lg animate-float">
                <Play className="w-5 h-5 mr-2 transition-transform duration-200 group-hover:scale-110" />
                Start Watching
              </Button>
            </Link>
            <Button variant="secondary" className="bg-gray-800 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-700 transition-all duration-300 hover:scale-105 hover:shadow-lg">
              <Info className="w-5 h-5 mr-2 transition-transform duration-200 group-hover:scale-110" />
              More Info
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
