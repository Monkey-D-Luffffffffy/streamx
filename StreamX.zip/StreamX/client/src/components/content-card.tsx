import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ContentCardProps } from "@/lib/types";

export default function ContentCard({
  id,
  title,
  thumbnailUrl,
  genre,
  year,
  duration,
  isOriginal,
  onClick
}: ContentCardProps) {
  return (
    <Card 
      className="content-card bg-stream-gray rounded-lg overflow-hidden cursor-pointer border-gray-700 hover:border-primary/50 group"
      onClick={onClick}
    >
      <div className="relative overflow-hidden">
        <img 
          src={thumbnailUrl}
          alt={`${title} poster`}
          className="w-full h-64 object-cover transition-all duration-500 group-hover:scale-110 group-hover:brightness-110"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300" />
        
        {/* Play overlay on hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
          <div className="bg-primary/90 rounded-full p-3 animate-pulse-glow">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-primary-foreground">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
        </div>
        
        
      </div>
      <div className="p-3 group-hover:bg-stream-dark/50 transition-all duration-300">
        <h3 className="font-semibold truncate text-white group-hover:text-primary transition-colors duration-300">{title}</h3>
        <div className="flex items-center text-gray-400 text-sm mt-1 group-hover:text-gray-300 transition-colors duration-300">
          {genre && <span>{genre}</span>}
          {genre && year && <span className="mx-1">•</span>}
          {year && <span>{year}</span>}
          {duration && (
            <>
              <span className="mx-1">•</span>
              <span>{duration}</span>
            </>
          )}
        </div>
      </div>
    </Card>
  );
}
