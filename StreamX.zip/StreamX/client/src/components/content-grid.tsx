import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import ContentCard from "./content-card";
import { ContentGridProps } from "@/lib/types";
import { Content } from "@shared/schema";

export default function ContentGrid({ 
  title, 
  content, 
  showViewAll = true, 
  onViewAll 
}: ContentGridProps) {
  return (
    <div className="mb-12 animate-fade-in">
      <div className="flex items-center justify-between mb-6 animate-slide-in">
        <h2 className="text-3xl font-bold">{title}</h2>
        {showViewAll && (
          <Button 
            variant="link" 
            className="text-primary hover:text-primary/80 transition-all duration-300 hover:scale-105"
            onClick={onViewAll}
          >
            View All
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {content.map((item: Content, index: number) => (
          <Link key={item.id} href={`/watch/${item.id}`}>
            <div 
              className="animate-fade-in stagger-animation" 
              style={{"--stagger": index} as any}
            >
              <ContentCard
                id={item.id}
                title={item.title}
                thumbnailUrl={item.thumbnailUrl}
                genre={item.genre}
                year={item.year}
                duration={item.duration}
                isOriginal={item.isOriginal === 1}
              />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
