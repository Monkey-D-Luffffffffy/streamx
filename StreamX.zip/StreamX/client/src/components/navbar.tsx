import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, User, Menu, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useIsMobile } from "@/hooks/use-mobile";

interface NavbarProps {
  onSearch?: (query: string) => void;
}

export default function Navbar({ onSearch }: NavbarProps) {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const isMobile = useIsMobile();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim() && onSearch) {
      onSearch(searchQuery.trim());
    }
  };

  const navLinks = [
    { href: "/", label: "Home", active: location === "/" },
    { href: "/browse/popular", label: "Movies", active: location.startsWith("/browse") && location.includes("popular") },
    { href: "/browse/tv", label: "TV Shows", active: location.startsWith("/browse") && location.includes("tv") },
    { href: "/browse/original", label: "Originals", active: location.startsWith("/browse") && location.includes("original") },
    { href: "/watchlist", label: "My List", active: location === "/watchlist" },
  ];

  const NavContent = () => (
    <>
      <div className="flex items-center space-x-8">
        {navLinks.map((link) => (
          <Link key={link.href} href={link.href} className={`transition-colors ${
              link.active 
                ? "text-primary font-medium" 
                : "text-gray-300 hover:text-white"
            }`}>
              {link.label}
          </Link>
        ))}
      </div>

      <div className="flex items-center space-x-4">
        <form onSubmit={handleSearch} className="relative">
          <Input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            className={`bg-gray-800 border-gray-700 text-white rounded-full py-2 px-4 pl-10 w-64 focus:outline-none transition-all ${
              isSearchFocused ? "ring-2 ring-primary" : ""
            }`}
          />
          <Search className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
        </form>

        <Button variant="ghost" size="icon" className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90">
          <User className="w-4 h-4" />
        </Button>
      </div>
    </>
  );

  return (
    <nav className="fixed top-0 w-full navbar-blur z-50 border-b border-gray-800 animate-slide-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center space-x-2 group">
              <div className="bg-primary rounded-lg p-2 transition-all duration-300 group-hover:scale-110 animate-pulse-glow">
                <div className="w-6 h-6 text-primary-foreground flex items-center justify-center">
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 transition-transform duration-300 group-hover:rotate-12">
                    <path d="M8 5v14l11-7z"/>
                  </svg>
                </div>
              </div>
              <span className="text-2xl font-bold transition-all duration-300 group-hover:scale-105">
                Stream<span className="text-primary">X</span>
              </span>
            </a>
          </Link>

          {/* Desktop Navigation */}
          {!isMobile && <NavContent />}

          {/* Mobile Navigation */}
          {isMobile && (
            <div className="flex items-center space-x-2">
              <form onSubmit={handleSearch} className="relative">
                <Input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white rounded-full py-2 px-4 pl-10 w-40"
                />
                <Search className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
              </form>

              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="bg-stream-dark border-gray-800">
                  <div className="flex flex-col space-y-4 mt-8">
                    {navLinks.map((link) => (
                      <Link key={link.href} href={link.href} className={`text-lg transition-colors ${
                          link.active 
                            ? "text-primary font-medium" 
                            : "text-gray-300 hover:text-white"
                        }`}>
                          {link.label}
                      </Link>
                    ))}
                    <div className="pt-4 border-t border-gray-700">
                      <Button variant="ghost" className="justify-start">
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}