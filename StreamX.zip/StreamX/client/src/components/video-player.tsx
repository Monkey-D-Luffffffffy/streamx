import { useState } from "react";
import { VideoPlayerProps } from "@/lib/types";

export default function VideoPlayer({ 
  googleDriveUrl, 
  title,
  onPlay,
  onPause 
}: VideoPlayerProps) {

  return (
    <div className="bg-stream-dark rounded-xl overflow-hidden animate-fade-in group">
      <div className="relative aspect-video">
        {/* Google Drive Embed */}
        <iframe
          src={googleDriveUrl}
          className="w-full h-full transition-all duration-500 group-hover:scale-[1.02]"
          allow="autoplay; encrypted-media; fullscreen"
          allowFullScreen
          frameBorder="0"
          title={`${title} - Video Player`}
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        />
        
        
        
        {/* Loading overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-0 pointer-events-none">
          <div className="animate-pulse-glow">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-16 h-16 text-primary">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
