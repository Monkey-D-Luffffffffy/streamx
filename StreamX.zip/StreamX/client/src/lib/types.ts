export interface SearchParams {
  q?: string;
  category?: string;
  type?: string;
}

export interface VideoPlayerProps {
  googleDriveUrl: string;
  title: string;
  onPlay?: () => void;
  onPause?: () => void;
}

export interface ContentCardProps {
  id: string;
  title: string;
  thumbnailUrl: string;
  genre?: string;
  year?: number;
  duration?: string;
  isOriginal?: boolean;
  onClick?: () => void;
}

export interface ContentGridProps {
  title: string;
  content: any[];
  showViewAll?: boolean;
  onViewAll?: () => void;
}

export const GOOGLE_DRIVE_EMBED_BASE = "https://drive.google.com/file/d/";
export const GOOGLE_DRIVE_EMBED_SUFFIX = "/preview";

export function formatGoogleDriveUrl(fileId: string): string {
  return `${GOOGLE_DRIVE_EMBED_BASE}${fileId}${GOOGLE_DRIVE_EMBED_SUFFIX}`;
}

export function extractFileIdFromUrl(url: string): string | null {
  const match = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  return match ? match[1] : null;
}
