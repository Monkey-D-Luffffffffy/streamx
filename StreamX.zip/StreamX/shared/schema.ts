import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const content = pgTable("content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  year: integer("year").notNull(),
  duration: text("duration").notNull(),
  genre: text("genre").notNull(),
  type: text("type").notNull(), // 'movie' | 'tv' | 'original'
  category: text("category").notNull(), // 'trending' | 'popular' | 'original'
  thumbnailUrl: text("thumbnail_url").notNull(),
  googleDriveUrl: text("google_drive_url").notNull(),
  rating: text("rating"), // 'HD', '4K', etc.
  isOriginal: integer("is_original").default(0), // 0 or 1 for boolean
});

export const watchlist = pgTable("watchlist", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  contentId: text("content_id").notNull(),
});

export const insertContentSchema = createInsertSchema(content).omit({
  id: true,
});

export const insertWatchlistSchema = createInsertSchema(watchlist).omit({
  id: true,
});

export type InsertContent = z.infer<typeof insertContentSchema>;
export type Content = typeof content.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;
export type Watchlist = typeof watchlist.$inferSelect;
